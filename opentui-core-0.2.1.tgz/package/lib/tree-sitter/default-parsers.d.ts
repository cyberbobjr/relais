import type { FiletypeParserOptions } from "./types.js";
export declare function getParsers(): FiletypeParserOptions[];
