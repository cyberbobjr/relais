import type { RGBA } from "./lib/RGBA.js";
import type { EventEmitter } from "events";
import type { Selection } from "./lib/selection.js";
import type { Renderable } from "./Renderable.js";
import type { InternalKeyHandler, KeyHandler } from "./lib/KeyHandler.js";
import type { EditBufferRenderable } from "./renderables/EditBufferRenderable.js";
export declare const TextAttributes: {
    NONE: number;
    BOLD: number;
    DIM: number;
    ITALIC: number;
    UNDERLINE: number;
    BLINK: number;
    INVERSE: number;
    HIDDEN: number;
    STRIKETHROUGH: number;
};
export declare const ATTRIBUTE_BASE_BITS = 8;
export declare const ATTRIBUTE_BASE_MASK = 255;
/**
 * Extract the base 8 bits of attributes from a u32 attribute value.
 * Currently we only use the first 8 bits for standard text attributes.
 */
export declare function getBaseAttributes(attr: number): number;
export type ThemeMode = "dark" | "light";
export type CursorStyle = "block" | "line" | "underline" | "default";
export type MousePointerStyle = "default" | "pointer" | "text" | "crosshair" | "move" | "not-allowed";
export interface CursorStyleOptions {
    style?: CursorStyle;
    blinking?: boolean;
    color?: RGBA;
    cursor?: MousePointerStyle;
}
export declare enum DebugOverlayCorner {
    topLeft = 0,
    topRight = 1,
    bottomLeft = 2,
    bottomRight = 3
}
export declare enum TargetChannel {
    FG = 1,
    BG = 2,
    Both = 3
}
export type WidthMethod = "wcwidth" | "unicode";
export interface RendererEvents {
    resize: (width: number, height: number) => void;
    key: (data: Buffer) => void;
    "memory:snapshot": (snapshot: {
        heapUsed: number;
        heapTotal: number;
        arrayBuffers: number;
    }) => void;
    selection: (selection: Selection) => void;
    focused_renderable: (current: Renderable | null, previous: Renderable | null) => void;
    focused_editor: (current: EditBufferRenderable | null, previous: EditBufferRenderable | null) => void;
    "debugOverlay:toggle": (enabled: boolean) => void;
    theme_mode: (mode: ThemeMode) => void;
}
export interface RenderContext extends EventEmitter {
    addToHitGrid: (x: number, y: number, width: number, height: number, id: number) => void;
    pushHitGridScissorRect: (x: number, y: number, width: number, height: number) => void;
    popHitGridScissorRect: () => void;
    clearHitGridScissorRects: () => void;
    width: number;
    height: number;
    /** Monotonic, bumped once per `loop()` iteration. Lets renderables dedupe per-frame work. */
    frameId: number;
    requestRender: () => void;
    setCursorPosition: (x: number, y: number, visible: boolean) => void;
    setCursorStyle: (options: CursorStyleOptions) => void;
    setCursorColor: (color: RGBA) => void;
    setMousePointer: (shape: MousePointerStyle) => void;
    widthMethod: WidthMethod;
    capabilities: any | null;
    requestLive: () => void;
    dropLive: () => void;
    hasSelection: boolean;
    getSelection: () => Selection | null;
    requestSelectionUpdate: () => void;
    currentFocusedRenderable: Renderable | null;
    currentFocusedEditor: EditBufferRenderable | null;
    focusRenderable: (renderable: Renderable) => void;
    blurRenderable: (renderable: Renderable) => void;
    claimFirstLineOffset?: (renderable?: Renderable) => number;
    registerLifecyclePass: (renderable: Renderable) => void;
    unregisterLifecyclePass: (renderable: Renderable) => void;
    getLifecyclePasses: () => Set<Renderable>;
    keyInput: KeyHandler;
    _internalKeyInput: InternalKeyHandler;
    clearSelection: () => void;
    startSelection: (renderable: Renderable, x: number, y: number) => void;
    updateSelection: (currentRenderable: Renderable | undefined, x: number, y: number, options?: {
        finishDragging?: boolean;
    }) => void;
}
export type Timeout = ReturnType<typeof setTimeout> | undefined;
export interface ViewportBounds {
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface Highlight {
    start: number;
    end: number;
    styleId: number;
    priority?: number | null;
    hlRef?: number | null;
}
export interface LineInfo {
    /** Display-column offset for each visual line start. */
    lineStartCols: number[];
    /** Display-column width for each visual line. */
    lineWidthCols: number[];
    /** Maximum display-column width across the reported lines. */
    lineWidthColsMax: number;
    /** Source logical line index for each visual line. */
    lineSources: number[];
    /** Wrap index within each source logical line. */
    lineWraps: number[];
}
export interface LineInfoProvider {
    get lineInfo(): LineInfo;
    get lineCount(): number;
    get virtualLineCount(): number;
    get scrollY(): number;
}
export interface CapturedSpan {
    text: string;
    fg: RGBA;
    bg: RGBA;
    attributes: number;
    width: number;
}
export interface CapturedLine {
    spans: CapturedSpan[];
}
export interface CapturedFrame {
    cols: number;
    rows: number;
    cursor: [number, number];
    lines: CapturedLine[];
}
