export interface WriteFileOptions {
    createPath?: boolean;
    mode?: number;
}
export declare const sleep: (msOrDate: number | Date) => Promise<void>;
export declare const stringWidth: (text: string) => number;
export declare const stripANSI: (text: string) => string;
export declare const writeFile: (destination: string | URL, data: string | ArrayBufferView, options?: WriteFileOptions) => Promise<number>;
