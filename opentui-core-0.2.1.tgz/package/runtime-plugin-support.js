// @bun
import {
  createRuntimePlugin,
  runtimeModuleIdForSpecifier
} from "./index-htg1x5tj.js";
import"./index-hxymw48q.js";
import"./index-b9g14b8c.js";

// src/runtime-plugin-support.ts
var {plugin: registerBunPlugin } = globalThis.Bun;
var runtimePluginSupportInstalledKey = "__opentuiCoreRuntimePluginSupportInstalled__";
function ensureRuntimePluginSupport(options = {}) {
  const state = globalThis;
  if (state[runtimePluginSupportInstalledKey]) {
    return false;
  }
  registerBunPlugin(createRuntimePlugin(options));
  state[runtimePluginSupportInstalledKey] = true;
  return true;
}
ensureRuntimePluginSupport();
export {
  runtimeModuleIdForSpecifier,
  ensureRuntimePluginSupport,
  createRuntimePlugin
};

//# debugId=7487C2BFD13C698664756E2164756E21
//# sourceMappingURL=runtime-plugin-support.js.map
