import { createRuntimePlugin, runtimeModuleIdForSpecifier, type CreateRuntimePluginOptions, type RuntimeModuleEntry, type RuntimeModuleExports, type RuntimeModuleLoader } from "./runtime-plugin.js";
export declare function ensureRuntimePluginSupport(options?: CreateRuntimePluginOptions): boolean;
export { createRuntimePlugin, runtimeModuleIdForSpecifier, type CreateRuntimePluginOptions, type RuntimeModuleEntry, type RuntimeModuleExports, type RuntimeModuleLoader, };
