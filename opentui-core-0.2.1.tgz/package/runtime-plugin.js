// @bun
import {
  createRuntimePlugin,
  isCoreRuntimeModuleSpecifier,
  runtimeModuleIdForSpecifier
} from "./index-htg1x5tj.js";
import"./index-hxymw48q.js";
import"./index-b9g14b8c.js";
export {
  runtimeModuleIdForSpecifier,
  isCoreRuntimeModuleSpecifier,
  createRuntimePlugin
};

//# debugId=54AC4E2ADFC3366A64756E2164756E21
//# sourceMappingURL=runtime-plugin.js.map
