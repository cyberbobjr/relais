import { type Pointer } from "bun:ffi";
import { type CursorStyle, type CursorStyleOptions, type TargetChannel, type DebugOverlayCorner, type WidthMethod, type Highlight, type LineInfo } from "./types.js";
export type { LineInfo, AllocatorStats, BuildOptions };
import { RGBA } from "./lib/RGBA.js";
import { OptimizedBuffer } from "./buffer.js";
import { TextBuffer } from "./text-buffer.js";
import type { NativeSpanFeedOptions, NativeSpanFeedStats, ReserveInfo, BuildOptions, AllocatorStats } from "./zig-structs.js";
export declare enum LogLevel {
    Error = 0,
    Warn = 1,
    Info = 2,
    Debug = 3
}
/**
 * VisualCursor represents a cursor position with both visual and logical coordinates.
 * Visual coordinates (visualRow, visualCol) are VIEWPORT-RELATIVE.
 * This means visualRow=0 is the first visible line in the viewport, not the first line in the document.
 * Logical coordinates (logicalRow, logicalCol) are document-absolute.
 */
export interface VisualCursor {
    visualRow: number;
    visualCol: number;
    logicalRow: number;
    logicalCol: number;
    offset: number;
}
export interface LogicalCursor {
    row: number;
    col: number;
    offset: number;
}
export interface CursorState {
    x: number;
    y: number;
    visible: boolean;
    style: CursorStyle;
    blinking: boolean;
    color: RGBA;
}
export type NativeSpanFeedEventHandler = (eventId: number, arg0: Pointer, arg1: number | bigint) => void;
export interface RenderLib {
    createRenderer: (width: number, height: number, options?: {
        testing?: boolean;
        remote?: boolean;
    }) => Pointer | null;
    setTerminalEnvVar: (renderer: Pointer, key: string, value: string) => boolean;
    destroyRenderer: (renderer: Pointer) => void;
    setUseThread: (renderer: Pointer, useThread: boolean) => void;
    setClearOnShutdown: (renderer: Pointer, clear: boolean) => void;
    setBackgroundColor: (renderer: Pointer, color: RGBA) => void;
    setRenderOffset: (renderer: Pointer, offset: number) => void;
    resetSplitScrollback: (renderer: Pointer, seedRows: number, pinnedRenderOffset: number) => number;
    syncSplitScrollback: (renderer: Pointer, pinnedRenderOffset: number) => number;
    setPendingSplitFooterTransition: (renderer: Pointer, mode: number, sourceTopLine: number, sourceHeight: number, targetTopLine: number, targetHeight: number) => void;
    clearPendingSplitFooterTransition: (renderer: Pointer) => void;
    updateStats: (renderer: Pointer, time: number, fps: number, frameCallbackTime: number) => void;
    updateMemoryStats: (renderer: Pointer, heapUsed: number, heapTotal: number, arrayBuffers: number) => void;
    render: (renderer: Pointer, force: boolean) => void;
    repaintSplitFooter: (renderer: Pointer, pinnedRenderOffset: number, force: boolean) => number;
    commitSplitFooterSnapshot: (renderer: Pointer, snapshot: OptimizedBuffer, rowColumns: number, startOnNewLine: boolean, trailingNewline: boolean, pinnedRenderOffset: number, force: boolean, beginFrame?: boolean, finalizeFrame?: boolean) => number;
    getNextBuffer: (renderer: Pointer) => OptimizedBuffer;
    getCurrentBuffer: (renderer: Pointer) => OptimizedBuffer;
    rendererSetPaletteState: (renderer: Pointer, palette: readonly RGBA[], defaultForeground: RGBA, defaultBackground: RGBA, paletteEpoch: number) => void;
    createOptimizedBuffer: (width: number, height: number, widthMethod: WidthMethod, respectAlpha?: boolean, id?: string) => OptimizedBuffer;
    destroyOptimizedBuffer: (bufferPtr: Pointer) => void;
    drawFrameBuffer: (targetBufferPtr: Pointer, destX: number, destY: number, bufferPtr: Pointer, sourceX?: number, sourceY?: number, sourceWidth?: number, sourceHeight?: number) => void;
    getBufferWidth: (buffer: Pointer) => number;
    getBufferHeight: (buffer: Pointer) => number;
    bufferClear: (buffer: Pointer, color: RGBA) => void;
    bufferGetCharPtr: (buffer: Pointer) => Pointer;
    bufferGetFgPtr: (buffer: Pointer) => Pointer;
    bufferGetBgPtr: (buffer: Pointer) => Pointer;
    bufferGetAttributesPtr: (buffer: Pointer) => Pointer;
    bufferGetRespectAlpha: (buffer: Pointer) => boolean;
    bufferSetRespectAlpha: (buffer: Pointer, respectAlpha: boolean) => void;
    bufferGetId: (buffer: Pointer) => string;
    bufferGetRealCharSize: (buffer: Pointer) => number;
    bufferWriteResolvedChars: (buffer: Pointer, outputBuffer: Uint8Array, addLineBreaks: boolean) => number;
    bufferDrawText: (buffer: Pointer, text: string, x: number, y: number, color: RGBA, bgColor?: RGBA, attributes?: number) => void;
    bufferSetCellWithAlphaBlending: (buffer: Pointer, x: number, y: number, char: string, color: RGBA, bgColor: RGBA, attributes?: number) => void;
    bufferSetCell: (buffer: Pointer, x: number, y: number, char: string, color: RGBA, bgColor: RGBA, attributes?: number) => void;
    bufferFillRect: (buffer: Pointer, x: number, y: number, width: number, height: number, color: RGBA) => void;
    bufferColorMatrix: (buffer: Pointer, matrixPtr: Pointer, cellMaskPtr: Pointer, cellMaskCount: number, strength: number, target: TargetChannel) => void;
    bufferColorMatrixUniform: (buffer: Pointer, matrixPtr: Pointer, strength: number, target: TargetChannel) => void;
    bufferDrawSuperSampleBuffer: (buffer: Pointer, x: number, y: number, pixelDataPtr: Pointer, pixelDataLength: number, format: "bgra8unorm" | "rgba8unorm", alignedBytesPerRow: number) => void;
    bufferDrawPackedBuffer: (buffer: Pointer, dataPtr: Pointer, dataLen: number, posX: number, posY: number, terminalWidthCells: number, terminalHeightCells: number) => void;
    bufferDrawGrayscaleBuffer: (buffer: Pointer, posX: number, posY: number, intensitiesPtr: Pointer, srcWidth: number, srcHeight: number, fg: RGBA | null, bg: RGBA | null) => void;
    bufferDrawGrayscaleBufferSupersampled: (buffer: Pointer, posX: number, posY: number, intensitiesPtr: Pointer, srcWidth: number, srcHeight: number, fg: RGBA | null, bg: RGBA | null) => void;
    bufferDrawGrid: (buffer: Pointer, borderChars: Uint32Array, borderFg: RGBA, borderBg: RGBA, columnOffsets: Int32Array, columnCount: number, rowOffsets: Int32Array, rowCount: number, options: {
        drawInner: boolean;
        drawOuter: boolean;
    }) => void;
    bufferDrawBox: (buffer: Pointer, x: number, y: number, width: number, height: number, borderChars: Uint32Array, packedOptions: number, borderColor: RGBA, backgroundColor: RGBA, title: string | null, bottomTitle: string | null) => void;
    bufferResize: (buffer: Pointer, width: number, height: number) => void;
    resizeRenderer: (renderer: Pointer, width: number, height: number) => void;
    setCursorPosition: (renderer: Pointer, x: number, y: number, visible: boolean) => void;
    setCursorColor: (renderer: Pointer, color: RGBA) => void;
    getCursorState: (renderer: Pointer) => CursorState;
    setCursorStyleOptions: (renderer: Pointer, options: CursorStyleOptions) => void;
    setDebugOverlay: (renderer: Pointer, enabled: boolean, corner: DebugOverlayCorner) => void;
    clearTerminal: (renderer: Pointer) => void;
    setTerminalTitle: (renderer: Pointer, title: string) => void;
    copyToClipboardOSC52: (renderer: Pointer, target: number, payload: Uint8Array) => boolean;
    clearClipboardOSC52: (renderer: Pointer, target: number) => boolean;
    addToHitGrid: (renderer: Pointer, x: number, y: number, width: number, height: number, id: number) => void;
    clearCurrentHitGrid: (renderer: Pointer) => void;
    hitGridPushScissorRect: (renderer: Pointer, x: number, y: number, width: number, height: number) => void;
    hitGridPopScissorRect: (renderer: Pointer) => void;
    hitGridClearScissorRects: (renderer: Pointer) => void;
    addToCurrentHitGridClipped: (renderer: Pointer, x: number, y: number, width: number, height: number, id: number) => void;
    checkHit: (renderer: Pointer, x: number, y: number) => number;
    getHitGridDirty: (renderer: Pointer) => boolean;
    dumpHitGrid: (renderer: Pointer) => void;
    dumpBuffers: (renderer: Pointer, timestamp?: number) => void;
    dumpStdoutBuffer: (renderer: Pointer, timestamp?: number) => void;
    restoreTerminalModes: (renderer: Pointer) => void;
    enableMouse: (renderer: Pointer, enableMovement: boolean) => void;
    disableMouse: (renderer: Pointer) => void;
    enableKittyKeyboard: (renderer: Pointer, flags: number) => void;
    disableKittyKeyboard: (renderer: Pointer) => void;
    setKittyKeyboardFlags: (renderer: Pointer, flags: number) => void;
    getKittyKeyboardFlags: (renderer: Pointer) => number;
    setupTerminal: (renderer: Pointer, useAlternateScreen: boolean) => void;
    suspendRenderer: (renderer: Pointer) => void;
    resumeRenderer: (renderer: Pointer) => void;
    queryPixelResolution: (renderer: Pointer) => void;
    queryThemeColors: (renderer: Pointer) => void;
    writeOut: (renderer: Pointer, data: string | Uint8Array) => void;
    createTextBuffer: (widthMethod: WidthMethod) => TextBuffer;
    destroyTextBuffer: (buffer: Pointer) => void;
    textBufferGetLength: (buffer: Pointer) => number;
    textBufferGetByteSize: (buffer: Pointer) => number;
    textBufferReset: (buffer: Pointer) => void;
    textBufferClear: (buffer: Pointer) => void;
    textBufferRegisterMemBuffer: (buffer: Pointer, bytes: Uint8Array, owned?: boolean) => number;
    textBufferReplaceMemBuffer: (buffer: Pointer, memId: number, bytes: Uint8Array, owned?: boolean) => boolean;
    textBufferClearMemRegistry: (buffer: Pointer) => void;
    textBufferSetTextFromMem: (buffer: Pointer, memId: number) => void;
    textBufferAppend: (buffer: Pointer, bytes: Uint8Array) => void;
    textBufferAppendFromMemId: (buffer: Pointer, memId: number) => void;
    textBufferLoadFile: (buffer: Pointer, path: string) => boolean;
    textBufferSetStyledText: (buffer: Pointer, chunks: Array<{
        text: string;
        fg?: RGBA | null;
        bg?: RGBA | null;
        attributes?: number;
        link?: {
            url: string;
        };
    }>) => void;
    textBufferSetDefaultFg: (buffer: Pointer, fg: RGBA | null) => void;
    textBufferSetDefaultBg: (buffer: Pointer, bg: RGBA | null) => void;
    textBufferSetDefaultAttributes: (buffer: Pointer, attributes: number | null) => void;
    textBufferResetDefaults: (buffer: Pointer) => void;
    textBufferGetTabWidth: (buffer: Pointer) => number;
    textBufferSetTabWidth: (buffer: Pointer, width: number) => void;
    textBufferGetLineCount: (buffer: Pointer) => number;
    getPlainTextBytes: (buffer: Pointer, maxLength: number) => Uint8Array | null;
    textBufferGetTextRange: (buffer: Pointer, startOffset: number, endOffset: number, maxLength: number) => Uint8Array | null;
    textBufferGetTextRangeByCoords: (buffer: Pointer, startRow: number, startCol: number, endRow: number, endCol: number, maxLength: number) => Uint8Array | null;
    createTextBufferView: (textBuffer: Pointer) => Pointer;
    destroyTextBufferView: (view: Pointer) => void;
    textBufferViewSetSelection: (view: Pointer, start: number, end: number, bgColor: RGBA | null, fgColor: RGBA | null) => void;
    textBufferViewResetSelection: (view: Pointer) => void;
    textBufferViewGetSelection: (view: Pointer) => {
        start: number;
        end: number;
    } | null;
    textBufferViewSetLocalSelection: (view: Pointer, anchorX: number, anchorY: number, focusX: number, focusY: number, bgColor: RGBA | null, fgColor: RGBA | null) => boolean;
    textBufferViewUpdateSelection: (view: Pointer, end: number, bgColor: RGBA | null, fgColor: RGBA | null) => void;
    textBufferViewUpdateLocalSelection: (view: Pointer, anchorX: number, anchorY: number, focusX: number, focusY: number, bgColor: RGBA | null, fgColor: RGBA | null) => boolean;
    textBufferViewResetLocalSelection: (view: Pointer) => void;
    textBufferViewSetWrapWidth: (view: Pointer, width: number) => void;
    textBufferViewSetWrapMode: (view: Pointer, mode: "none" | "char" | "word") => void;
    textBufferViewSetFirstLineOffset: (view: Pointer, offset: number) => void;
    textBufferViewSetViewportSize: (view: Pointer, width: number, height: number) => void;
    textBufferViewSetViewport: (view: Pointer, x: number, y: number, width: number, height: number) => void;
    textBufferViewGetLineInfo: (view: Pointer) => LineInfo;
    textBufferViewGetLogicalLineInfo: (view: Pointer) => LineInfo;
    textBufferViewGetSelectedTextBytes: (view: Pointer, maxLength: number) => Uint8Array | null;
    textBufferViewGetPlainTextBytes: (view: Pointer, maxLength: number) => Uint8Array | null;
    textBufferViewSetTabIndicator: (view: Pointer, indicator: number) => void;
    textBufferViewSetTabIndicatorColor: (view: Pointer, color: RGBA) => void;
    textBufferViewSetTruncate: (view: Pointer, truncate: boolean) => void;
    textBufferViewMeasureForDimensions: (view: Pointer, width: number, height: number) => {
        lineCount: number;
        widthColsMax: number;
    } | null;
    textBufferViewGetVirtualLineCount: (view: Pointer) => number;
    readonly encoder: TextEncoder;
    readonly decoder: TextDecoder;
    bufferDrawTextBufferView: (buffer: Pointer, view: Pointer, x: number, y: number) => void;
    bufferDrawEditorView: (buffer: Pointer, view: Pointer, x: number, y: number) => void;
    createEditBuffer: (widthMethod: WidthMethod) => Pointer;
    destroyEditBuffer: (buffer: Pointer) => void;
    editBufferSetText: (buffer: Pointer, textBytes: Uint8Array) => void;
    editBufferSetTextFromMem: (buffer: Pointer, memId: number) => void;
    editBufferReplaceText: (buffer: Pointer, textBytes: Uint8Array) => void;
    editBufferReplaceTextFromMem: (buffer: Pointer, memId: number) => void;
    editBufferGetText: (buffer: Pointer, maxLength: number) => Uint8Array | null;
    editBufferInsertChar: (buffer: Pointer, char: string) => void;
    editBufferInsertText: (buffer: Pointer, text: string) => void;
    editBufferDeleteChar: (buffer: Pointer) => void;
    editBufferDeleteCharBackward: (buffer: Pointer) => void;
    editBufferDeleteRange: (buffer: Pointer, startLine: number, startCol: number, endLine: number, endCol: number) => void;
    editBufferNewLine: (buffer: Pointer) => void;
    editBufferDeleteLine: (buffer: Pointer) => void;
    editBufferMoveCursorLeft: (buffer: Pointer) => void;
    editBufferMoveCursorRight: (buffer: Pointer) => void;
    editBufferMoveCursorUp: (buffer: Pointer) => void;
    editBufferMoveCursorDown: (buffer: Pointer) => void;
    editBufferGotoLine: (buffer: Pointer, line: number) => void;
    editBufferSetCursor: (buffer: Pointer, line: number, col: number) => void;
    editBufferSetCursorToLineCol: (buffer: Pointer, line: number, col: number) => void;
    editBufferSetCursorByOffset: (buffer: Pointer, offset: number) => void;
    editBufferGetCursorPosition: (buffer: Pointer) => LogicalCursor;
    editBufferGetId: (buffer: Pointer) => number;
    editBufferGetTextBuffer: (buffer: Pointer) => Pointer;
    editBufferDebugLogRope: (buffer: Pointer) => void;
    editBufferUndo: (buffer: Pointer, maxLength: number) => Uint8Array | null;
    editBufferRedo: (buffer: Pointer, maxLength: number) => Uint8Array | null;
    editBufferCanUndo: (buffer: Pointer) => boolean;
    editBufferCanRedo: (buffer: Pointer) => boolean;
    editBufferClearHistory: (buffer: Pointer) => void;
    editBufferClear: (buffer: Pointer) => void;
    editBufferGetNextWordBoundary: (buffer: Pointer) => {
        row: number;
        col: number;
        offset: number;
    };
    editBufferGetPrevWordBoundary: (buffer: Pointer) => {
        row: number;
        col: number;
        offset: number;
    };
    editBufferGetEOL: (buffer: Pointer) => {
        row: number;
        col: number;
        offset: number;
    };
    editBufferOffsetToPosition: (buffer: Pointer, offset: number) => {
        row: number;
        col: number;
        offset: number;
    } | null;
    editBufferPositionToOffset: (buffer: Pointer, row: number, col: number) => number;
    editBufferGetLineStartOffset: (buffer: Pointer, row: number) => number;
    editBufferGetTextRange: (buffer: Pointer, startOffset: number, endOffset: number, maxLength: number) => Uint8Array | null;
    editBufferGetTextRangeByCoords: (buffer: Pointer, startRow: number, startCol: number, endRow: number, endCol: number, maxLength: number) => Uint8Array | null;
    createEditorView: (editBufferPtr: Pointer, viewportWidth: number, viewportHeight: number) => Pointer;
    destroyEditorView: (view: Pointer) => void;
    editorViewSetViewportSize: (view: Pointer, width: number, height: number) => void;
    editorViewSetViewport: (view: Pointer, x: number, y: number, width: number, height: number, moveCursor: boolean) => void;
    editorViewGetViewport: (view: Pointer) => {
        offsetY: number;
        offsetX: number;
        height: number;
        width: number;
    };
    editorViewSetScrollMargin: (view: Pointer, margin: number) => void;
    editorViewSetWrapMode: (view: Pointer, mode: "none" | "char" | "word") => void;
    editorViewGetVirtualLineCount: (view: Pointer) => number;
    editorViewGetTotalVirtualLineCount: (view: Pointer) => number;
    editorViewGetTextBufferView: (view: Pointer) => Pointer;
    editorViewSetSelection: (view: Pointer, start: number, end: number, bgColor: RGBA | null, fgColor: RGBA | null) => void;
    editorViewResetSelection: (view: Pointer) => void;
    editorViewGetSelection: (view: Pointer) => {
        start: number;
        end: number;
    } | null;
    editorViewSetLocalSelection: (view: Pointer, anchorX: number, anchorY: number, focusX: number, focusY: number, bgColor: RGBA | null, fgColor: RGBA | null, updateCursor: boolean, followCursor: boolean) => boolean;
    editorViewUpdateSelection: (view: Pointer, end: number, bgColor: RGBA | null, fgColor: RGBA | null) => void;
    editorViewUpdateLocalSelection: (view: Pointer, anchorX: number, anchorY: number, focusX: number, focusY: number, bgColor: RGBA | null, fgColor: RGBA | null, updateCursor: boolean, followCursor: boolean) => boolean;
    editorViewResetLocalSelection: (view: Pointer) => void;
    editorViewGetSelectedTextBytes: (view: Pointer, maxLength: number) => Uint8Array | null;
    editorViewGetCursor: (view: Pointer) => {
        row: number;
        col: number;
    };
    editorViewGetText: (view: Pointer, maxLength: number) => Uint8Array | null;
    editorViewGetVisualCursor: (view: Pointer) => VisualCursor;
    editorViewMoveUpVisual: (view: Pointer) => void;
    editorViewMoveDownVisual: (view: Pointer) => void;
    editorViewDeleteSelectedText: (view: Pointer) => void;
    editorViewSetCursorByOffset: (view: Pointer, offset: number) => void;
    editorViewGetNextWordBoundary: (view: Pointer) => VisualCursor;
    editorViewGetPrevWordBoundary: (view: Pointer) => VisualCursor;
    editorViewGetEOL: (view: Pointer) => VisualCursor;
    editorViewGetVisualSOL: (view: Pointer) => VisualCursor;
    editorViewGetVisualEOL: (view: Pointer) => VisualCursor;
    editorViewGetLineInfo: (view: Pointer) => LineInfo;
    editorViewGetLogicalLineInfo: (view: Pointer) => LineInfo;
    editorViewSetPlaceholderStyledText: (view: Pointer, chunks: Array<{
        text: string;
        fg?: RGBA | null;
        bg?: RGBA | null;
        attributes?: number;
    }>) => void;
    editorViewSetTabIndicator: (view: Pointer, indicator: number) => void;
    editorViewSetTabIndicatorColor: (view: Pointer, color: RGBA) => void;
    bufferPushScissorRect: (buffer: Pointer, x: number, y: number, width: number, height: number) => void;
    bufferPopScissorRect: (buffer: Pointer) => void;
    bufferClearScissorRects: (buffer: Pointer) => void;
    bufferPushOpacity: (buffer: Pointer, opacity: number) => void;
    bufferPopOpacity: (buffer: Pointer) => void;
    bufferGetCurrentOpacity: (buffer: Pointer) => number;
    bufferClearOpacity: (buffer: Pointer) => void;
    textBufferAddHighlightByCharRange: (buffer: Pointer, highlight: Highlight) => void;
    textBufferAddHighlight: (buffer: Pointer, lineIdx: number, highlight: Highlight) => void;
    textBufferRemoveHighlightsByRef: (buffer: Pointer, hlRef: number) => void;
    textBufferClearLineHighlights: (buffer: Pointer, lineIdx: number) => void;
    textBufferClearAllHighlights: (buffer: Pointer) => void;
    textBufferSetSyntaxStyle: (buffer: Pointer, style: Pointer | null) => void;
    textBufferGetLineHighlights: (buffer: Pointer, lineIdx: number) => Array<Highlight>;
    textBufferGetHighlightCount: (buffer: Pointer) => number;
    getArenaAllocatedBytes: () => number;
    getBuildOptions: () => BuildOptions;
    getAllocatorStats: () => AllocatorStats;
    createSyntaxStyle: () => Pointer;
    destroySyntaxStyle: (style: Pointer) => void;
    syntaxStyleRegister: (style: Pointer, name: string, fg: RGBA | null, bg: RGBA | null, attributes: number) => number;
    syntaxStyleResolveByName: (style: Pointer, name: string) => number | null;
    syntaxStyleGetStyleCount: (style: Pointer) => number;
    getTerminalCapabilities: (renderer: Pointer) => any;
    processCapabilityResponse: (renderer: Pointer, response: string) => void;
    encodeUnicode: (text: string, widthMethod: WidthMethod) => {
        ptr: Pointer;
        data: Array<{
            width: number;
            char: number;
        }>;
    } | null;
    freeUnicode: (encoded: {
        ptr: Pointer;
        data: Array<{
            width: number;
            char: number;
        }>;
    }) => void;
    bufferDrawChar: (buffer: Pointer, char: number, x: number, y: number, fg: RGBA, bg: RGBA, attributes?: number) => void;
    registerNativeSpanFeedStream: (stream: Pointer, handler: NativeSpanFeedEventHandler) => void;
    unregisterNativeSpanFeedStream: (stream: Pointer) => void;
    createNativeSpanFeed: (options?: NativeSpanFeedOptions | null) => Pointer;
    attachNativeSpanFeed: (stream: Pointer) => number;
    destroyNativeSpanFeed: (stream: Pointer) => void;
    streamWrite: (stream: Pointer, data: Uint8Array | string) => number;
    streamCommit: (stream: Pointer) => number;
    streamDrainSpans: (stream: Pointer, outBuffer: Uint8Array, maxSpans: number) => number;
    streamClose: (stream: Pointer) => number;
    streamSetOptions: (stream: Pointer, options: NativeSpanFeedOptions) => number;
    streamGetStats: (stream: Pointer) => NativeSpanFeedStats | null;
    streamReserve: (stream: Pointer, minLen: number) => {
        status: number;
        info: ReserveInfo | null;
    };
    streamCommitReserved: (stream: Pointer, length: number) => number;
    onNativeEvent: (name: string, handler: (data: ArrayBuffer) => void) => void;
    onceNativeEvent: (name: string, handler: (data: ArrayBuffer) => void) => void;
    offNativeEvent: (name: string, handler: (data: ArrayBuffer) => void) => void;
    onAnyNativeEvent: (handler: (name: string, data: ArrayBuffer) => void) => void;
}
export declare function setRenderLibPath(libPath: string): void;
export declare function resolveRenderLib(): RenderLib;
